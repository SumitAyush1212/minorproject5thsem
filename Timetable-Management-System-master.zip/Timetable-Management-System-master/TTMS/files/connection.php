<?php
/**
 * Created by PhpStorm.
 * User: MSaqib
 * Date: 31-08-2016
 * Time: 02:57
 */

$con = mysqli_connect("localhost", "root", "", "ttms");
?>