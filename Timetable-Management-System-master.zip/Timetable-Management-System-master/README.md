# Timetable-Management-System
A PHP project developed under a 5th semester departmental course 'Minor Project'.
Includes features such as creation, modification of timetable for a departme,import data using excel file .
Generates clash free timetable with additional features such as SMS alert to teachers' mobile number using WAY2SMS api.
Generating and saving timetable as pdf using jsPDF.

Note: downlaod and place jsPDF api in the location '..../TTMS/files/assets/' .
